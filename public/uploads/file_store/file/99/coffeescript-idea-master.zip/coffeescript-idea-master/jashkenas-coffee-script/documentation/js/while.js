(function(){
  var _a, lyrics, num;
  // Econ 101
  if (this.studying_economics) {
    while (supply > demand) {
      buy();
    }
    while (supply < demand) {
      sell();
    }
  }
  // Nursery Rhyme
  num = 6;
  lyrics = (function() {
    _a = [];
    while (num -= 1) {
      _a.push(num + " little monkeys, jumping on the bed. \
One fell out and bumped his head.");
    }
    return _a;
  }).call(this);
})();
