(function(){
  var date, expensive, mood;
  if (singing) {
    mood = greatly_improved;
  }
  if (happy && knows_it) {
    claps_hands();
    cha_cha_cha();
  }
  date = friday ? sue : jill;
  expensive = expensive || do_the_math();
})();
