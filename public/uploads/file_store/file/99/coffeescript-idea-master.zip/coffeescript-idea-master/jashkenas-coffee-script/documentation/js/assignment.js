(function(){
  var difficulty, greeting;
  greeting = "Hello CoffeeScript";
  difficulty = 0.5;
})();
