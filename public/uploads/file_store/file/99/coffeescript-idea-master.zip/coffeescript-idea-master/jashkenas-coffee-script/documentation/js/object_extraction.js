(function(){
  var _a, _b, _c, city, futurists, poet, street;
  futurists = {
    sculptor: "Umberto Boccioni",
    painter: "Vladimir Burliuk",
    poet: {
      name: "F.T. Marinetti",
      address: ["Via Roma 42R", "Bellagio, Italy 22021"]
    }
  };
  _a = futurists;
  _b = _a.poet;
  poet = _b.name;
  _c = _b.address;
  street = _c[0];
  city = _c[1];
})();
