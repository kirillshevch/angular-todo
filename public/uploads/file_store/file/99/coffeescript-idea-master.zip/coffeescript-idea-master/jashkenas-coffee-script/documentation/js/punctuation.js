(function(){

  // Comments start with hash marks. Periods mark the end of a block.
  var left_hand = raining ? umbrella : parasol;
  // To signal the beginning of the next expression,
  // use "then", or a newline.
  left_hand = raining ? umbrella : parasol;
})();