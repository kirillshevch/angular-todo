(function(){
  var _a, close, contents, open, tag;
  tag = "<impossible>";
  _a = tag.split("");
  open = _a[0];
  contents = Array.prototype.slice.call(_a, 1, _a.length - 1);
  close = _a[_a.length - 1];
})();
