(function(){
  try {
    all_hell_breaks_loose();
    cats_and_dogs_living_together();
  } catch (error) {
    print(error);
  } finally {
    clean_up();
  }
})();
