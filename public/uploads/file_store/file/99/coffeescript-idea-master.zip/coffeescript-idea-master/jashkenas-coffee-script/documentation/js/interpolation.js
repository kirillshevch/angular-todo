(function(){
  var author, quote;
  author = "Wittgenstein";
  quote = "A picture is a fact. -- " + author;
})();
