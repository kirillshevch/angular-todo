(function(){
  var volume;
  if (ignition === true) {
    launch();
  }
  if (band !== spinal_tap) {
    volume = 10;
  }
  if (!(answer === false)) {
    let_the_wild_rumpus_begin();
  }
  car.speed < speed_limit ? accelerate() : null;
  print("My name is " + this.name);
})();
