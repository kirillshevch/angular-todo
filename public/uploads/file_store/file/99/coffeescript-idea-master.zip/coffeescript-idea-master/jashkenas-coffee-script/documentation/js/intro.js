(function(){

  // CoffeeScript on the left, JS on the right.
  var square = function(x) {
    return x * x;
  };
})();