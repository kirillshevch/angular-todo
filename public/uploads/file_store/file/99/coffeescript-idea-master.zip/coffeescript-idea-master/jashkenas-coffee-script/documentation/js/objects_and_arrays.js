(function(){
  var ages, matrix, song;
  song = ["do", "re", "mi", "fa", "so"];
  ages = {
    max: 10,
    ida: 9,
    tim: 11
  };
  matrix = [1, 0, 1, 0, 0, 1, 1, 1, 0];
})();
