(function(){
  var change_numbers, new_num, num;
  num = 1;
  change_numbers = function change_numbers() {
    var new_num;
    new_num = -1;
    num = 10;
    return num;
  };
  new_num = change_numbers();
})();
