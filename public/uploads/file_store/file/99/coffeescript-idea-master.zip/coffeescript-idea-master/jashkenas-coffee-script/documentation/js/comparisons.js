(function(){
  var cholesterol, healthy;
  cholesterol = 127;
  healthy = (200 > cholesterol) && (cholesterol > 60);
})();
