(function(){
  var _a, and_switch, bait;
  bait = 1000;
  and_switch = 0;
  _a = [and_switch, bait];
  bait = _a[0];
  and_switch = _a[1];
})();
