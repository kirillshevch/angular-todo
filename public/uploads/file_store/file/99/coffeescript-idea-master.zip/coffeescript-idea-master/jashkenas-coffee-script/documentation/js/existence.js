(function(){
  var solipsism, speed;
  if ((typeof mind !== "undefined" && mind !== null) && !(typeof world !== "undefined" && world !== null)) {
    solipsism = true;
  }
  speed = (typeof speed !== "undefined" && speed !== null) ? speed : 140;
})();
