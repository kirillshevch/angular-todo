(function(){
  var numbers, numbers_copy, three_to_six;
  numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  three_to_six = numbers.slice(3, 6 + 1);
  numbers_copy = numbers.slice(0, numbers.length);
})();
